# Video Downloader — Flutter Frontend v2.0

A polished Flutter app for the **VideoDownloaderV2** Flask backend. Supports Android and iOS, features real-time download progress via Socket.IO, a searchable file browser, dark/light theme, and a configurable server URL.

---

## What's new in v2.0

| Area | Changes |
|---|---|
| **iOS** | Full iOS support: `Info.plist`, `AppDelegate.swift`, `Podfile`, HTTP-to-localhost transport exception |
| **Dependencies** | Removed unmaintained `filesize` package; replaced with a built-in formatter. Added `flutter_animate`, `google_fonts`, `shared_preferences`. All packages pinned to latest stable. |
| **UI** | Material 3 + Google Fonts (Inter). Gradient hero AppBar. Dark mode. Animated cards. Live connection badge. |
| **UX** | Settings screen for server URL (persisted). Dismiss completed/failed jobs. Search/filter files. Total storage stat. |
| **Resilience** | Timeouts on all HTTP calls. Socket reconnection. Error snackbars with colour-coded feedback. |

---

## Getting started

### Prerequisites
- Flutter **3.22+** (`flutter --version`)
- For iOS: Xcode 15+, CocoaPods (`sudo gem install cocoapods`)
- Your [VideoDownloaderV2](https://github.com/) backend running

### 1 · Clone & fetch packages
```bash
git clone <repo>
cd flutter_app
flutter pub get
```

### 2 · Android
```bash
flutter run -d android
```

### 3 · iOS — generate Xcode project (first time only)
The `ios/` folder already contains `Info.plist`, `AppDelegate.swift`, and `Podfile`.  
You still need Flutter to generate the Xcode project scaffold and install pods:

```bash
flutter create --platforms=ios .   # generates ios/Runner.xcodeproj etc.
cd ios && pod install && cd ..
flutter run -d ios
```

> **Note:** The `Info.plist` already contains `NSAllowsLocalNetworking = true` so the app can reach your LAN server over HTTP. Once you put the backend behind HTTPS, remove the `NSExceptionDomains` block.

### 4 · Configure the server URL
On first launch the app points to `https://videodownloaderv2.onrender.com`.  
Open **Settings → Backend URL → Edit** and enter your server's LAN IP, e.g. `https://videodownloaderv2.onrender.com`.  
The URL is persisted via `shared_preferences`.

---

## Project structure

```
lib/
├── main.dart                  # App entry point, theme toggle
├── models/
│   └── download_model.dart    # DownloadJob, DownloadedFile
├── screens/
│   ├── home_screen.dart       # URL form + live progress list
│   ├── files_screen.dart      # Searchable file browser
│   └── settings_screen.dart   # Server URL + appearance
├── services/
│   └── api_service.dart       # HTTP + Socket.IO, ChangeNotifier
├── theme/
│   └── app_theme.dart         # Light & dark ThemeData
├── utils/
│   └── file_utils.dart        # formatFileSize helper
└── widgets/
    └── download_card.dart     # Animated progress card
ios/
├── Podfile                    # CocoaPods config (iOS 13+)
└── Runner/
    ├── AppDelegate.swift      # Flutter iOS entry point
    └── Info.plist             # Permissions, HTTP exceptions
android/
└── app/src/main/
    └── AndroidManifest.xml   # Internet permission, edge-to-edge
```

---

## Dependencies

| Package | Version | Purpose |
|---|---|---|
| `http` | ^1.2.2 | REST API calls |
| `socket_io_client` | ^2.0.3+1 | Real-time progress |
| `provider` | ^6.1.2 | State management |
| `url_launcher` | ^6.3.1 | Open files externally |
| `intl` | ^0.19.0 | Date formatting |
| `shared_preferences` | ^2.3.2 | Persist server URL |
| `flutter_animate` | ^4.5.0 | Animations |
| `google_fonts` | ^6.2.1 | Inter typeface |
