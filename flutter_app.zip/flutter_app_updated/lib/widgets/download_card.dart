import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/download_model.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import 'package:provider/provider.dart';

/// An animated card showing live progress for an active [DownloadJob].
class DownloadCard extends StatelessWidget {
  final DownloadJob job;

  const DownloadCard({super.key, required this.job});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final (icon, color, bgColor) = _iconColorBg(job.status);
    final isDone = job.status == 'completed' || job.status == 'failed';

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 8, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Header row ─────────────────────────────────────────────────
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Status icon
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: bgColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: job.status == 'downloading'
                      ? Padding(
                          padding: const EdgeInsets.all(10),
                          child: CircularProgressIndicator(
                            value: job.percent > 0 ? job.percent / 100 : null,
                            strokeWidth: 2.5,
                            color: color,
                            backgroundColor: color.withOpacity(0.2),
                          ),
                        )
                      : Icon(icon, color: color, size: 22),
                ),
                const SizedBox(width: 12),
                // Title + status chip
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        job.title,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      _StatusChip(status: job.status, color: color),
                    ],
                  ),
                ),
                // Dismiss button for finished jobs
                if (isDone)
                  IconButton(
                    icon: const Icon(Icons.close_rounded, size: 18),
                    color: Colors.grey.shade400,
                    tooltip: 'Dismiss',
                    onPressed: () =>
                        context.read<ApiService>().dismissJob(job.id),
                  ),
              ],
            ),

            const SizedBox(height: 14),

            // ── Progress bar ────────────────────────────────────────────────
            Stack(
              children: [
                // Track
                Container(
                  height: 6,
                  decoration: BoxDecoration(
                    color: theme.brightness == Brightness.dark
                        ? Colors.white.withOpacity(0.08)
                        : Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(6),
                  ),
                ),
                // Fill
                AnimatedFractionallySizedBox(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeOut,
                  widthFactor: job.status == 'completed'
                      ? 1.0
                      : job.status == 'failed'
                          ? 0.0
                          : (job.percent / 100).clamp(0.0, 1.0),
                  child: Container(
                    height: 6,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [color.withOpacity(0.7), color],
                      ),
                      borderRadius: BorderRadius.circular(6),
                      boxShadow: [
                        BoxShadow(
                          color: color.withOpacity(0.4),
                          blurRadius: 4,
                          offset: const Offset(0, 1),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 8),

            // ── Footer row ──────────────────────────────────────────────────
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _footerLabel(job),
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: Colors.grey.shade500,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                if (job.status == 'downloading')
                  Text(
                    '${job.percent.toStringAsFixed(1)}%',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: color,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _footerLabel(DownloadJob job) => switch (job.status) {
        'completed' => '✓ Download complete',
        'failed' => '✗ Download failed',
        'downloading' => 'Downloading…',
        _ => 'Queued — waiting to start',
      };

  static (IconData, Color, Color) _iconColorBg(String status) =>
      switch (status) {
        'completed' => (
            Icons.check_rounded,
            AppTheme.success,
            AppTheme.success.withOpacity(0.12),
          ),
        'failed' => (
            Icons.error_outline_rounded,
            AppTheme.error,
            AppTheme.error.withOpacity(0.12),
          ),
        'downloading' => (
            Icons.download_rounded,
            AppTheme.info,
            AppTheme.info.withOpacity(0.12),
          ),
        _ => (
            Icons.hourglass_top_rounded,
            AppTheme.warning,
            AppTheme.warning.withOpacity(0.12),
          ),
      };
}

class _StatusChip extends StatelessWidget {
  final String status;
  final Color color;

  const _StatusChip({required this.status, required this.color});

  static const _labels = {
    'completed': 'Completed',
    'failed': 'Failed',
    'downloading': 'Downloading',
    'queued': 'Queued',
  };

  @override
  Widget build(BuildContext context) {
    final label = _labels[status] ?? status;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (status == 'downloading')
            Padding(
              padding: const EdgeInsets.only(right: 4),
              child: SizedBox(
                width: 8,
                height: 8,
                child: CircularProgressIndicator(
                  strokeWidth: 1.5,
                  color: color,
                ),
              ),
            )
          else
            Container(
              width: 6,
              height: 6,
              margin: const EdgeInsets.only(right: 5),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color,
              ),
            ),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    )
        .animate(
          onPlay: (c) => status == 'downloading' ? c.repeat() : null,
        )
        .shimmer(
          duration: 1800.ms,
          color: color.withOpacity(status == 'downloading' ? 0.3 : 0),
        );
  }
}
