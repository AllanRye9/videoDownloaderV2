import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../models/download_model.dart';
import '../utils/file_utils.dart';
import '../theme/app_theme.dart';

class FilesScreen extends StatefulWidget {
  const FilesScreen({super.key});

  @override
  State<FilesScreen> createState() => _FilesScreenState();
}

class _FilesScreenState extends State<FilesScreen> {
  final _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ApiService>().fetchFiles();
    });
    _searchCtrl.addListener(() => setState(() => _query = _searchCtrl.text));
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  List<DownloadedFile> _filtered(List<DownloadedFile> files) {
    if (_query.isEmpty) return files;
    final q = _query.toLowerCase();
    return files.where((f) => f.name.toLowerCase().contains(q)).toList();
  }

  @override
  Widget build(BuildContext context) {
    final api = context.watch<ApiService>();
    final filtered = _filtered(api.files);

    return Scaffold(
      body: NestedScrollView(
        headerSliverBuilder: (_, __) => [
          SliverAppBar(
            pinned: true,
            floating: true,
            backgroundColor: AppTheme.primary,
            expandedHeight: 100,
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: 20, bottom: 14),
              title: Row(
                children: [
                  const Icon(Icons.folder_rounded, color: Colors.white, size: 22),
                  const SizedBox(width: 8),
                  Text(
                    'Downloaded Files',
                    style: Theme.of(context).appBarTheme.titleTextStyle,
                  ),
                ],
              ),
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppTheme.primaryDark, AppTheme.primary, Color(0xFF9B5CF6)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.refresh_rounded, color: Colors.white),
                tooltip: 'Refresh',
                onPressed: () => api.fetchFiles(),
              ),
            ],
          ),
        ],
        body: Column(
          children: [
            // Search bar
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
              child: TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(
                  hintText: 'Search files…',
                  prefixIcon: const Icon(Icons.search_rounded,
                      color: AppTheme.primary),
                  suffixIcon: _query.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.clear_rounded),
                          onPressed: () {
                            _searchCtrl.clear();
                            setState(() => _query = '');
                          },
                        )
                      : null,
                ),
              ).animate().fadeIn(duration: 300.ms),
            ),

            // Stats row
            if (api.files.isNotEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Row(
                  children: [
                    _StatChip(
                      icon: Icons.insert_drive_file_rounded,
                      label: '${api.files.length} file${api.files.length == 1 ? '' : 's'}',
                    ),
                    const SizedBox(width: 8),
                    _StatChip(
                      icon: Icons.storage_rounded,
                      label: formatFileSize(
                          api.files.fold(0, (s, f) => s + f.sizeBytes)),
                    ),
                  ],
                ),
              ),

            // File list
            Expanded(
              child: api.filesLoading
                  ? const Center(
                      child: CircularProgressIndicator(color: AppTheme.primary),
                    )
                  : api.files.isEmpty
                      ? _EmptyFilesState()
                          .animate()
                          .fadeIn(delay: 200.ms, duration: 400.ms)
                      : filtered.isEmpty
                          ? Center(
                              child: Text(
                                'No files match "$_query"',
                                style: TextStyle(color: Colors.grey.shade500),
                              ),
                            )
                          : RefreshIndicator(
                              onRefresh: api.fetchFiles,
                              color: AppTheme.primary,
                              child: ListView.builder(
                                padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
                                itemCount: filtered.length,
                                itemBuilder: (_, i) => _FileCard(
                                  file: filtered[i],
                                  api: api,
                                )
                                    .animate(delay: (i * 40).ms)
                                    .fadeIn(duration: 300.ms)
                                    .slideY(begin: 0.04),
                              ),
                            ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _StatChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: AppTheme.primary.withOpacity(0.10),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: AppTheme.primary),
          const SizedBox(width: 5),
          Text(label,
              style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.primary)),
        ],
      ),
    );
  }
}

class _FileCard extends StatelessWidget {
  final DownloadedFile file;
  final ApiService api;

  const _FileCard({required this.file, required this.api});

  Future<void> _open(BuildContext context) async {
    final url = Uri.parse(api.fileUrl(file.name));
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cannot open: ${url.toString()}'),
          backgroundColor: AppTheme.error,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final modifiedDate = DateTime.fromMillisecondsSinceEpoch(
      (file.modified * 1000).toInt(),
    );
    final dateStr = DateFormat('d MMM yyyy · HH:mm').format(modifiedDate);
    final isVideo = RegExp(r'\.(mp4|mkv|webm|mov|avi|m4v)$')
        .hasMatch(file.name.toLowerCase());
    final isAudio =
        RegExp(r'\.(mp3|m4a|opus|flac|aac|wav)$').hasMatch(file.name.toLowerCase());

    final (icon, color) = isVideo
        ? (Icons.play_circle_rounded, AppTheme.primary)
        : isAudio
            ? (Icons.music_note_rounded, const Color(0xFFEC4899))
            : (Icons.insert_drive_file_rounded, Colors.grey.shade500);

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: () => _open(context),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              // Icon
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color, size: 26),
              ),
              const SizedBox(width: 14),
              // Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      file.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.straighten_rounded,
                            size: 12, color: Colors.grey.shade500),
                        const SizedBox(width: 4),
                        Text(
                          formatFileSize(file.sizeBytes),
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(color: Colors.grey.shade500),
                        ),
                        const SizedBox(width: 10),
                        Icon(Icons.schedule_rounded,
                            size: 12, color: Colors.grey.shade500),
                        const SizedBox(width: 4),
                        Text(
                          dateStr,
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(color: Colors.grey.shade500),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // Open button
              IconButton(
                icon: const Icon(Icons.open_in_new_rounded),
                color: AppTheme.primary,
                tooltip: 'Open / Play',
                onPressed: () => _open(context),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyFilesState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.folder_open_rounded,
              size: 72, color: Colors.grey.withOpacity(0.4)),
          const SizedBox(height: 16),
          Text(
            'No files yet',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Colors.grey,
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 6),
          Text(
            'Downloads you complete will appear here.',
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .bodySmall
                ?.copyWith(color: Colors.grey.shade500),
          ),
        ],
      ),
    );
  }
}
