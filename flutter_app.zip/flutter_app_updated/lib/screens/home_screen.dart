import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../main.dart';
import '../services/api_service.dart';
import '../widgets/download_card.dart';
import '../theme/app_theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _formKey = GlobalKey<FormState>();
  final _urlCtrl = TextEditingController();
  final _cookiesCtrl = TextEditingController();
  String _format = 'best';
  bool _showCookies = false;
  bool _submitting = false;

  static const _formats = [
    ('Best quality', 'best'),
    ('Best video + audio (MP4)', 'bestvideo+bestaudio/best'),
    ('1080p', 'bestvideo[height<=1080]+bestaudio/best'),
    ('720p', 'bestvideo[height<=720]+bestaudio/best'),
    ('480p', 'bestvideo[height<=480]+bestaudio/best'),
    ('Audio only (MP3)', 'bestaudio[ext=mp3]/bestaudio'),
  ];

  @override
  void dispose() {
    _urlCtrl.dispose();
    _cookiesCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _submitting = true);

    final api = context.read<ApiService>();
    final id = await api.startDownload(
      url: _urlCtrl.text.trim(),
      format: _format,
      cookies: _showCookies ? _cookiesCtrl.text.trim() : null,
    );

    if (!mounted) return;
    setState(() => _submitting = false);

    if (id == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(
            children: [
              Icon(Icons.error_outline, color: Colors.white),
              SizedBox(width: 8),
              Text('Failed to start download. Check server settings.'),
            ],
          ),
          backgroundColor: AppTheme.error,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    } else {
      _urlCtrl.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(
            children: [
              Icon(Icons.check_circle_outline, color: Colors.white),
              SizedBox(width: 8),
              Text('Download queued!'),
            ],
          ),
          backgroundColor: AppTheme.success,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = VideoDownloaderApp.of(context)?.isDark ?? true;
    final jobs = context.watch<ApiService>().activeJobs.values.toList()
      ..sort((a, b) {
        const order = {'downloading': 0, 'queued': 1, 'completed': 2, 'failed': 3};
        return (order[a.status] ?? 9).compareTo(order[b.status] ?? 9);
      });

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // ── Hero app bar ────────────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 120,
            pinned: true,
            stretch: true,
            backgroundColor: AppTheme.primary,
            flexibleSpace: FlexibleSpaceBar(
              stretchModes: const [StretchMode.zoomBackground],
              titlePadding: const EdgeInsets.only(left: 20, bottom: 14),
              title: Row(
                children: [
                  const Icon(Icons.download_rounded, color: Colors.white, size: 22),
                  const SizedBox(width: 8),
                  Text(
                    'Video Downloader',
                    style: Theme.of(context).appBarTheme.titleTextStyle,
                  ),
                ],
              ),
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppTheme.primaryDark, AppTheme.primary, Color(0xFF9B5CF6)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            ),
            actions: [
              _ConnectionBadge(),
              IconButton(
                icon: Icon(
                  isDark ? Icons.light_mode_rounded : Icons.dark_mode_rounded,
                  color: Colors.white,
                ),
                onPressed: () => VideoDownloaderApp.of(context)?.toggleTheme(),
                tooltip: 'Toggle theme',
              ),
              const SizedBox(width: 4),
            ],
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Download form card ───────────────────────────────────
                  _DownloadFormCard(
                    formKey: _formKey,
                    urlCtrl: _urlCtrl,
                    cookiesCtrl: _cookiesCtrl,
                    format: _format,
                    showCookies: _showCookies,
                    submitting: _submitting,
                    formats: _formats,
                    onFormatChanged: (v) => setState(() => _format = v!),
                    onCookiesToggle: (v) => setState(() => _showCookies = v ?? false),
                    onSubmit: _submit,
                  ).animate().fadeIn(duration: 400.ms).slideY(begin: 0.05),

                  const SizedBox(height: 28),

                  // ── Active downloads ─────────────────────────────────────
                  if (jobs.isNotEmpty) ...[
                    Row(
                      children: [
                        Text(
                          'Active Downloads',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w700,
                              ),
                        ),
                        const Spacer(),
                        _CountBadge(count: jobs.length),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ...jobs.asMap().entries.map(
                          (e) => DownloadCard(job: e.value)
                              .animate(delay: (e.key * 60).ms)
                              .fadeIn(duration: 350.ms)
                              .slideX(begin: 0.04),
                        ),
                  ] else ...[
                    _EmptyDownloadsHint()
                        .animate()
                        .fadeIn(delay: 300.ms, duration: 400.ms),
                  ],
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Sub-widgets ──────────────────────────────────────────────────────────────

class _ConnectionBadge extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final connected = context.watch<ApiService>().connected;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 400),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: connected
              ? AppTheme.success.withOpacity(0.25)
              : AppTheme.error.withOpacity(0.25),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: connected ? AppTheme.success : AppTheme.error,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 400),
              width: 6,
              height: 6,
              decoration: BoxDecoration(
                color: connected ? AppTheme.success : AppTheme.error,
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 5),
            Text(
              connected ? 'Live' : 'Offline',
              style: TextStyle(
                color: connected ? AppTheme.success : AppTheme.error,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DownloadFormCard extends StatelessWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController urlCtrl;
  final TextEditingController cookiesCtrl;
  final String format;
  final bool showCookies;
  final bool submitting;
  final List<(String, String)> formats;
  final ValueChanged<String?> onFormatChanged;
  final ValueChanged<bool?> onCookiesToggle;
  final VoidCallback onSubmit;

  const _DownloadFormCard({
    required this.formKey,
    required this.urlCtrl,
    required this.cookiesCtrl,
    required this.format,
    required this.showCookies,
    required this.submitting,
    required this.formats,
    required this.onFormatChanged,
    required this.onCookiesToggle,
    required this.onSubmit,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Header
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.primary.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.add_link_rounded,
                        color: AppTheme.primary, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'New Download',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // URL field
              TextFormField(
                controller: urlCtrl,
                keyboardType: TextInputType.url,
                autocorrect: false,
                decoration: const InputDecoration(
                  labelText: 'Video URL',
                  hintText: 'https://www.youtube.com/watch?v=…',
                  prefixIcon: Icon(Icons.link_rounded, color: AppTheme.primary),
                ),
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return 'Please enter a URL';
                  final uri = Uri.tryParse(v.trim());
                  if (uri == null || !uri.hasScheme) return 'Enter a valid URL';
                  return null;
                },
              ),
              const SizedBox(height: 14),

              // Format selector
              DropdownButtonFormField<String>(
                value: format,
                decoration: const InputDecoration(
                  labelText: 'Format / Quality',
                  prefixIcon:
                      Icon(Icons.high_quality_rounded, color: AppTheme.primary),
                ),
                borderRadius: BorderRadius.circular(12),
                items: formats
                    .map((f) => DropdownMenuItem(
                          value: f.$2,
                          child: Text(f.$1,
                              style: Theme.of(context).textTheme.bodyMedium),
                        ))
                    .toList(),
                onChanged: onFormatChanged,
              ),
              const SizedBox(height: 10),

              // Cookies toggle
              InkWell(
                onTap: () => onCookiesToggle(!showCookies),
                borderRadius: BorderRadius.circular(10),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 36,
                        height: 36,
                        child: Checkbox(
                          value: showCookies,
                          onChanged: onCookiesToggle,
                          activeColor: AppTheme.primary,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5)),
                        ),
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Provide cookies',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(fontWeight: FontWeight.w500)),
                            Text('For private or age-gated content',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(color: Colors.grey)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              if (showCookies) ...[
                const SizedBox(height: 10),
                TextFormField(
                  controller: cookiesCtrl,
                  maxLines: 4,
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                  decoration: const InputDecoration(
                    labelText: 'Cookies (Netscape format)',
                    hintText: '# Netscape HTTP Cookie File\n…',
                    alignLabelWithHint: true,
                  ),
                ),
              ],

              const SizedBox(height: 20),

              // Submit button
              FilledButton.icon(
                onPressed: submitting ? null : onSubmit,
                icon: submitting
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                            strokeWidth: 2.5, color: Colors.white),
                      )
                    : const Icon(Icons.download_rounded),
                label: Text(submitting ? 'Starting…' : 'Start Download'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CountBadge extends StatelessWidget {
  final int count;
  const _CountBadge({required this.count});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        color: AppTheme.primary.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        '$count',
        style: const TextStyle(
          color: AppTheme.primary,
          fontWeight: FontWeight.w700,
          fontSize: 13,
        ),
      ),
    );
  }
}

class _EmptyDownloadsHint extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Theme.of(context).dividerColor.withOpacity(0.5),
          width: 1.5,
        ),
      ),
      child: Column(
        children: [
          Icon(Icons.inbox_rounded,
              size: 48, color: Colors.grey.withOpacity(0.5)),
          const SizedBox(height: 12),
          Text(
            'No active downloads',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: Colors.grey,
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 4),
          Text(
            'Paste a video URL above and tap Start Download',
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .bodySmall
                ?.copyWith(color: Colors.grey.shade500),
          ),
        ],
      ),
    );
  }
}
