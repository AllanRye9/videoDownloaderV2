import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../main.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _urlCtrl;
  bool _editing = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _urlCtrl = TextEditingController(
        text: context.read<ApiService>().baseUrl);
  }

  @override
  void dispose() {
    _urlCtrl.dispose();
    super.dispose();
  }

  Future<void> _saveUrl() async {
    final url = _urlCtrl.text.trim();
    if (url.isEmpty) return;
    await context.read<ApiService>().setBaseUrl(url);
    setState(() => _editing = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(
            children: [
              Icon(Icons.check_circle_outline, color: Colors.white),
              SizedBox(width: 8),
              Text('Server URL updated'),
            ],
          ),
          backgroundColor: AppTheme.success,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final api = context.watch<ApiService>();
    final appState = VideoDownloaderApp.of(context);

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            backgroundColor: AppTheme.primary,
            expandedHeight: 100,
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: 20, bottom: 14),
              title: Row(
                children: [
                  const Icon(Icons.settings_rounded, color: Colors.white, size: 22),
                  const SizedBox(width: 8),
                  Text('Settings',
                      style: Theme.of(context).appBarTheme.titleTextStyle),
                ],
              ),
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppTheme.primaryDark, AppTheme.primary, Color(0xFF9B5CF6)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Server settings ──────────────────────────────────────
                  _SectionHeader(label: 'Server'),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Connection status row
                          Row(
                            children: [
                              AnimatedContainer(
                                duration: const Duration(milliseconds: 400),
                                width: 10,
                                height: 10,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: api.connected
                                      ? AppTheme.success
                                      : AppTheme.error,
                                  boxShadow: [
                                    BoxShadow(
                                      color: (api.connected
                                              ? AppTheme.success
                                              : AppTheme.error)
                                          .withOpacity(0.5),
                                      blurRadius: 6,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                api.connected
                                    ? 'Connected to server'
                                    : 'Not connected',
                                style: TextStyle(
                                  color: api.connected
                                      ? AppTheme.success
                                      : AppTheme.error,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          // URL field
                          if (_editing) ...[
                            TextField(
                              controller: _urlCtrl,
                              keyboardType: TextInputType.url,
                              autocorrect: false,
                              decoration: const InputDecoration(
                                labelText: 'Server URL',
                                hintText: 'https://videodownloaderv2.onrender.com',
                                prefixIcon: Icon(Icons.dns_rounded,
                                    color: AppTheme.primary),
                              ),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(
                                  child: OutlinedButton(
                                    onPressed: () =>
                                        setState(() => _editing = false),
                                    style: OutlinedButton.styleFrom(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                    ),
                                    child: const Text('Cancel'),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: FilledButton(
                                    onPressed: _saveUrl,
                                    child: const Text('Save'),
                                  ),
                                ),
                              ],
                            ),
                          ] else ...[
                            Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text('Backend URL',
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                  color: Colors.grey)),
                                      const SizedBox(height: 2),
                                      Text(
                                        api.baseUrl,
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyMedium
                                            ?.copyWith(
                                                fontWeight: FontWeight.w600,
                                                fontFamily: 'monospace'),
                                      ),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.edit_rounded),
                                  color: AppTheme.primary,
                                  onPressed: () =>
                                      setState(() => _editing = true),
                                  tooltip: 'Edit URL',
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                  ).animate().fadeIn(duration: 300.ms).slideY(begin: 0.04),

                  const SizedBox(height: 24),

                  // ── Appearance ─────────────────────────────────────────
                  _SectionHeader(label: 'Appearance'),
                  Card(
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 18, vertical: 4),
                      leading: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppTheme.primary.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(
                          appState?.isDark == true
                              ? Icons.dark_mode_rounded
                              : Icons.light_mode_rounded,
                          color: AppTheme.primary,
                        ),
                      ),
                      title: const Text('Dark Mode',
                          style: TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text(
                          appState?.isDark == true ? 'Enabled' : 'Disabled',
                          style: TextStyle(
                              color: Colors.grey.shade500, fontSize: 12)),
                      trailing: Switch(
                        value: appState?.isDark ?? true,
                        onChanged: (_) => appState?.toggleTheme(),
                        activeColor: AppTheme.primary,
                      ),
                    ),
                  ).animate(delay: 60.ms).fadeIn(duration: 300.ms).slideY(begin: 0.04),

                  const SizedBox(height: 24),

                  // ── About ──────────────────────────────────────────────
                  _SectionHeader(label: 'About'),
                  Card(
                    child: Column(
                      children: [
                        _InfoTile(
                          icon: Icons.info_outline_rounded,
                          label: 'Version',
                          value: '2.0.0',
                        ),
                        const Divider(height: 1, indent: 62),
                        _InfoTile(
                          icon: Icons.code_rounded,
                          label: 'Framework',
                          value: 'Flutter (Material 3)',
                        ),
                        const Divider(height: 1, indent: 62),
                        _InfoTile(
                          icon: Icons.phone_android_rounded,
                          label: 'Platforms',
                          value: 'Android · iOS',
                        ),
                      ],
                    ),
                  ).animate(delay: 120.ms).fadeIn(duration: 300.ms).slideY(begin: 0.04),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String label;
  const _SectionHeader({required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 10),
      child: Text(
        label.toUpperCase(),
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: AppTheme.primary,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2,
            ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _InfoTile({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 2),
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppTheme.primary.withOpacity(0.10),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: AppTheme.primary, size: 18),
      ),
      title: Text(label,
          style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14)),
      trailing: Text(value,
          style: TextStyle(
              color: Colors.grey.shade500,
              fontSize: 13,
              fontWeight: FontWeight.w500)),
    );
  }
}
