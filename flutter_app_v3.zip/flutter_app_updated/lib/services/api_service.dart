import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;
import '../models/download_model.dart';

/// All communication with the VideoDownloaderV2 Flask backend.
class ApiService extends ChangeNotifier {
  // ── Configuration ────────────────────────────────────────────────────────
  static const String _defaultBaseUrl =
      'https://videodownloaderv2.onrender.com';
  static const String _prefKey = 'server_url';

  // Render free-tier can take ~30 s to cold-start; use a generous timeout.
  static const _shortTimeout = Duration(seconds: 10);
  static const _longTimeout = Duration(seconds: 45);

  String _baseUrl = _defaultBaseUrl;
  String get baseUrl => _baseUrl;

  // ── Internal state ────────────────────────────────────────────────────────
  io.Socket? _socket;
  final Map<String, DownloadJob> _activeJobs = {};
  List<DownloadedFile> _files = [];
  bool _filesLoading = false;
  bool _connected = false;
  bool _serverWaking = false; // true while waiting for cold-start

  // ── Public accessors ──────────────────────────────────────────────────────
  Map<String, DownloadJob> get activeJobs => Map.unmodifiable(_activeJobs);
  List<DownloadedFile> get files => List.unmodifiable(_files);
  bool get filesLoading => _filesLoading;
  bool get connected => _connected;
  bool get serverWaking => _serverWaking;

  // ── Constructor ────────────────────────────────────────────────────────────
  ApiService() {
    _loadPrefsAndInit();
  }

  Future<void> _loadPrefsAndInit() async {
    final prefs = await SharedPreferences.getInstance();
    _baseUrl = prefs.getString(_prefKey) ?? _defaultBaseUrl;
    _pingServer(); // wake Render instance early
    _initSocket();
  }

  /// Fire a lightweight GET to wake the Render instance before the user taps Download.
  Future<void> _pingServer() async {
    try {
      _serverWaking = true;
      notifyListeners();
      // /files is a safe, read-only endpoint for the ping
      await http.get(Uri.parse('$_baseUrl/files')).timeout(_longTimeout);
    } catch (_) {
      // Ignore — if it fails the real request will surface the error
    } finally {
      _serverWaking = false;
      notifyListeners();
    }
  }

  /// Persists a new server URL and reconnects.
  Future<void> setBaseUrl(String url) async {
    final trimmed = url.trim().replaceAll(RegExp(r'/$'), ''); // no trailing slash
    if (trimmed == _baseUrl) return;
    _baseUrl = trimmed;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKey, _baseUrl);
    _socket?.dispose();
    _activeJobs.clear();
    _files.clear();
    _connected = false;
    notifyListeners();
    _pingServer();
    _initSocket();
  }

  // ── Socket setup ──────────────────────────────────────────────────────────
  void _initSocket() {
    _socket = io.io(
      _baseUrl,
      io.OptionBuilder()
          .setTransports(['websocket', 'polling']) // fallback to polling
          .disableAutoConnect()
          .setTimeout(10000)
          .setReconnectionDelay(3000)
          .setReconnectionAttempts(5)
          .build(),
    );

    _socket!.onConnect((_) {
      _connected = true;
      debugPrint('Socket connected to $_baseUrl');
      notifyListeners();
    });
    _socket!.onDisconnect((_) {
      _connected = false;
      notifyListeners();
    });
    _socket!.onConnectError((e) {
      _connected = false;
      debugPrint('Socket error: $e');
      notifyListeners();
    });

    _socket!.on('progress', (data) {
      final id = data['id'] as String? ?? '';
      final line = data['line'] as String? ?? '';
      if (_activeJobs.containsKey(id)) {
        if (line.contains('%')) {
          try {
            final pctStr = line.split('%')[0].split(' ').last;
            _activeJobs[id]!.percent =
                double.parse(pctStr).clamp(0.0, 100.0);
          } catch (_) {}
        }
        _activeJobs[id]!.status = 'downloading';
        notifyListeners();
      }
    });

    _socket!.on('completed', (data) {
      final id = data['id'] as String? ?? '';
      if (_activeJobs.containsKey(id)) {
        _activeJobs[id]!.status = 'completed';
        _activeJobs[id]!.percent = 100;
        notifyListeners();
      }
      fetchFiles();
    });

    _socket!.on('failed', (data) {
      final id = data['id'] as String? ?? '';
      if (_activeJobs.containsKey(id)) {
        _activeJobs[id]!.status = 'failed';
        notifyListeners();
      }
    });

    _socket!.on('files_updated', (_) => fetchFiles());

    _socket!.connect();
  }

  // ── REST: start a new download ─────────────────────────────────────────────
  Future<String?> startDownload({
    required String url,
    String format = 'best',
    String? cookies,
  }) async {
    try {
      final uri = Uri.parse('$_baseUrl/start_download');

      // Build form-encoded body (Flask request.form)
      final fields = <String, String>{'url': url, 'format': format};
      if (cookies != null && cookies.isNotEmpty) fields['cookies'] = cookies;

      final response = await http
          .post(
            uri,
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
              'Accept': 'application/json',
            },
            body: fields,
          )
          .timeout(_longTimeout); // 45 s covers cold-start

      debugPrint('startDownload → ${response.statusCode}: ${response.body}');

      if (response.statusCode != 200) {
        debugPrint('Server error ${response.statusCode}: ${response.body}');
        return null;
      }

      final json = jsonDecode(response.body) as Map<String, dynamic>;
      final id = json['download_id'] as String?;
      if (id == null) return null;

      _activeJobs[id] = DownloadJob(
        id: id,
        url: url,
        title: 'Loading…',
        status: 'queued',
      );
      notifyListeners();

      _socket?.emit('subscribe', {'download_id': id});
      _refreshJobStatus(id);

      return id;
    } catch (e) {
      debugPrint('startDownload error: $e');
      return null;
    }
  }

  Future<void> _refreshJobStatus(String id) async {
    try {
      final response = await http
          .get(Uri.parse('$_baseUrl/status/$id'))
          .timeout(_shortTimeout);
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body) as Map<String, dynamic>;
        if (json.isNotEmpty) {
          _activeJobs[id] = DownloadJob.fromJson(json, id);
          notifyListeners();
        }
      }
    } catch (_) {}
  }

  /// Remove a completed/failed job from the active list.
  void dismissJob(String id) {
    _activeJobs.remove(id);
    notifyListeners();
  }

  Future<void> fetchFiles() async {
    _filesLoading = true;
    notifyListeners();
    try {
      final response = await http
          .get(
            Uri.parse('$_baseUrl/files'),
            headers: {'Accept': 'application/json'},
          )
          .timeout(_longTimeout);
      if (response.statusCode == 200) {
        final list = jsonDecode(response.body) as List<dynamic>;
        _files = list
            .map((e) => DownloadedFile.fromJson(e as Map<String, dynamic>))
            .toList()
          ..sort((a, b) => b.modified.compareTo(a.modified));
      }
    } catch (e) {
      debugPrint('fetchFiles error: $e');
    }
    _filesLoading = false;
    notifyListeners();
  }

  String fileUrl(String filename) => '$_baseUrl/downloads/$filename';

  @override
  void dispose() {
    _socket?.dispose();
    super.dispose();
  }
}
